/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lineasdibujables.logica;

/**
 *
 * @author estudiantes
 */
public class Punto {
    int x;
    int y;

    public Punto(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
    
    
}
