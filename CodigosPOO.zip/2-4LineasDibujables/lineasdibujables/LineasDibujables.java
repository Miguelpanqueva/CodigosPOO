/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lineasdibujables;

import lineasdibujables.gui.GUI;
import lineasdibujables.logica.Linea;
import lineasdibujables.logica.Punto;

/**
 *
 * @author estudiantes
 */
public class LineasDibujables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUI g = new GUI();
        g.setBounds(0, 0, 400, 400);
        g.setVisible(true);
    }
}
