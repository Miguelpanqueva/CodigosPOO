
public class ClaseStatic {
	int coodenadax;
	public static int radio;
	
	public static void imprimir (){
		System.out.println("impresion del metodo estatico con radio:"+radio);
	}
	
}
