/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package herencia;

/**
 *
 * @author Carlos
 */
public class Moto extends Vehiculo  {

   
}
