public class Prueba {

  public static void main (String args[]){
    char i ='2';
    switch (i) {
      case '1': System.out.println( "i contiene un 1"); break;
      case '2': System.out.println( "i contiene un 2"); break;
      case '3': System.out.println( "i contiene un 3"); break;
      default : System.out.println( "i no es 1, 2 ó 3 ");
    }
  }
}