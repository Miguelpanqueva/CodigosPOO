package go;

public class Ficha {

	private String color;
	
	public void dameColor (String color){
		this.color = color;
	}
	
	public String entregaColor (){
		return color;
	}
	
	
}
