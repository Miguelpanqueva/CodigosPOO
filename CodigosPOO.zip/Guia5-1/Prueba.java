git spublic class Prueba {


  public static void main (String args[]){
  int i=5;
  if (i == 5){ System.out.println(" i vale 5 ");}
  else {System.out.println("i no vale 5");}
  i=4;
  if (i == 5){ System.out.println(" i vale 5 ");}
  else if (i < 5){System.out.println("i es menor que 5");}
  else if (i > 5){System.out.println("i es mayor que 5");}
  }
}