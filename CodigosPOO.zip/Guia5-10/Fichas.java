public class Fichas {
  String color;
 
 public Fichas(String c){color=c;}
 
 public String dameColor(){return(color);}
}