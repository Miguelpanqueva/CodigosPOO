public class Prueba {
  public static void main (String args[]){
    int i=5;
    do
    {
      i --;
      System.out.println (i);
    } // las llaves aquí se pueden omitir puesto 
    while ( i > 0 ); // que solo hay una sentencia.
  }
}